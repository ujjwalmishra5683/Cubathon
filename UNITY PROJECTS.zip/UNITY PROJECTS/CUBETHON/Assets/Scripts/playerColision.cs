﻿using UnityEngine;

public class playerColision : MonoBehaviour {

    public PlayerMovement movement;      // A refernce to our PlayerMovement script.

    // This funcition runs when we hit another object.
    // We get info. about the collisition and call it "collisitionInfo".
    void OnCollisionEnter (Collision collisionInfo)
    {
        // Wew heck if the object we collided whith has a tag called "Obstacle".
        if (collisionInfo.collider.tag == "Obstacle")
        {
            movement.enabled = false;     // Disable the players movement.
            FindObjectOfType<GameManager>().EndGame();
        }
    }
}
 